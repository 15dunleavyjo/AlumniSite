﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlumniWebsiteLogin
{
    public partial class MainLoginPage : Form
    {
        public MainLoginPage()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        //Opens UserLogin 
        private void btnUserLogin_Click(object sender, EventArgs e)
        {
            //Instantiates new UserLogin
            UserLogin frmUserLogin = new UserLogin();
            //Shows frmUserLogin
            frmUserLogin.ShowDialog();
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            AdminLogin frmAdminLogin = new AdminLogin();
            frmAdminLogin.ShowDialog();
        }
    }
}
