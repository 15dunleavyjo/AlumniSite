﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlumniWebsiteLogin
{
    public partial class UpdateAdmins : Form
    {
        //Instantiates connectionString
        private string connectionString;
        //Instantiates SqlConnection connection
        private SqlConnection connection;
        //Instantiates SqlCommand command
        private SqlCommand command;
        private Admin Insert;
        private Admin Update;
        private Admin Delete;
            

        public UpdateAdmins()
        {
            InitializeComponent();
            //Declares a connection to the AlumniWebisteConnectionString
            connectionString = Properties.Settings.Default.AlumniWebsiteConnectionString;
            //Declares new connection using connectionString as its parameter
            connection = new SqlConnection(connectionString);
            Insert = new Admin();
            Update = new Admin();
            Delete = new Admin();
        }
        private void UpdateAdmins_Load(object sender, EventArgs e)
        {
            this.adminTableAdapter.Fill(this.alumniWebsiteDataSet.Admin);
        }

        private void btnAddAdmin_Click(object sender, EventArgs e)
        {
            //Sqlstatement to Insert new user into the Admin database            
            string Insert = "INSERT INTO Admin(FirstName, LastName, Password, UserName) " +
                            "VALUES(@pfirstName, @plastName, @ppassword, @puserName)";
            //parameterizes new SqlCommand command with Insert and connection
            command = new SqlCommand(Insert, connection);
            //tells the program what data to try and Insertinto database
            this.setInsert();
            try
            {
                //Opens database
                connection.Open();
                //Set parameters with values from getInsert
                this.getInsert();
                //Excutes the update Insert SQL statement
                command.ExecuteNonQuery();
            }
            //If theirs an error while executing try
            catch (Exception ex)
            {
                //Display an error messagebox with the error
                MessageBox.Show("DB error: " + ex.Message);
            }
            //Close connection
            connection.Close();
            //shows changes in database
            this.adminTableAdapter.Fill(this.alumniWebsiteDataSet.Admin);
        }
        private void setInsert()
        {
            
            //Declares FirstName with firstNameTextBox
            Insert.FirstName = firstNameTextBox.Text;
            //Declares LastName with lastNameTextBox
            Insert.LastName = lastNameTextBox.Text;
            Insert.UserName = userNameTextBox.Text;
            Insert.Password = passwordTextBox.Text;

        }
        private void getInsert()
        {
            command.Parameters.AddWithValue("@puserName", Insert.UserName);
            command.Parameters.AddWithValue("@pfirstName", Insert.FirstName);
            command.Parameters.AddWithValue("@plastName", Insert.LastName);
            command.Parameters.AddWithValue("@ppassword", Insert.Password);
            command.Parameters.AddWithValue("@padminID", Insert.UserName);
        }
        private void setUpdate()
        {
            Update.AdminID = int.Parse(adminIDTextBox.Text);
            //Declares FirstName with firstNameTextBox
            Update.FirstName = firstNameTextBox.Text;
            //Declares LastName with lastNameTextBox
            Update.LastName = lastNameTextBox.Text;
            Update.UserName = userNameTextBox.Text;
            Update.Password = passwordTextBox.Text;

        }
        private void getUpdate()
        {
            command.Parameters.AddWithValue("@puserName", Update.UserName);
            command.Parameters.AddWithValue("@pfirstName", Update.FirstName);
            command.Parameters.AddWithValue("@plastName", Update.LastName);
            command.Parameters.AddWithValue("@ppassword", Update.Password);
            command.Parameters.AddWithValue("@padminID", Update.UserName);
        }

        private void btnUpdateAdmin_Click(object sender, EventArgs e)
        {
             string Update = "UPDATE Admin SET FirstName = @pfirstName, LastName = @plastName, Password = @ppassword, UserName = @puserName " +
                              "WHERE(AdminID = @padminID)";
            //parameterizes new SqlCommand command with Insert and connection
            command = new SqlCommand(Update, connection);
            //tells the program what data to try and Insertinto database
            this.setUpdate();
            try
            {
                //Opens database
                connection.Open();
                //Set parameters with values from getInsert
                this.getUpdate();
                //Excutes the update Insert SQL statement
                command.ExecuteNonQuery();
            }
            //If theirs an error while executing try
            catch (Exception ex)
            {
                //Display an error messagebox with the error
                MessageBox.Show("DB error: " + ex.Message);
            }
            //Close connection
            connection.Close();
            //shows changes in database
            this.adminTableAdapter.Fill(this.alumniWebsiteDataSet.Admin);
        }
                private void btnDeleteAdmin_Click(object sender, EventArgs e)
        {
            string Delete = "DELETE FROM Admin WHERE(AdminID = @padminID)";
            command = new SqlCommand(Delete, connection);
            //tells the program what data to try and Insertinto database
            this.setDelete();
            try
            {
                //Opens database
                connection.Open();
                //Set parameters with values from getInsert
                this.getDelete();
                //Excutes the Delete Insert SQL statement
                command.ExecuteNonQuery();
            }
            //If theirs an error while executing try
            catch (Exception ex)
            {
                //Display an error messagebox with the error
                MessageBox.Show("DB error: " + ex.Message);
            }
            //Close connection
            connection.Close();
            //shows changes in database
            this.adminTableAdapter.Fill(this.alumniWebsiteDataSet.Admin);
        }
        private void setDelete()
        {
            Delete.AdminID = int.Parse(adminIDTextBox.Text);
            //Declares FirstName with firstNameTextBox
            Delete.FirstName = firstNameTextBox.Text;
            //Declares LastName with lastNameTextBox
            Delete.LastName = lastNameTextBox.Text;
            Delete.UserName = userNameTextBox.Text;
            Delete.Password = passwordTextBox.Text;

        }
        private void getDelete()
        {
            command.Parameters.AddWithValue("@padminID", Delete.UserName);
        }

        //Returns user to AdminPage form
        private void btnGoBack_Click(object sender, EventArgs e)
        {
            //Hides form returning the user to the main application
            this.DialogResult = DialogResult.OK;
        }

        private void btnProgram_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void adminDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
