﻿namespace AlumniWebsiteLogin
{


    partial class AlumniWebsiteDataSet
    {
        partial class UserDataTable
        {
        }
    }
}
