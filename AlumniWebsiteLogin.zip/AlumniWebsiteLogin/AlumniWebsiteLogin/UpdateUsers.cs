﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlumniWebsiteLogin
{
    public partial class UpdateUsers : Form
    {
        //Instantiates connectionString
        private string connectionString;
        //Instantiates SqlConnection connection
        private SqlConnection connection;
        //Instantiates SqlCommand command
        private SqlCommand command;
        private User Info;
        private User Update;
        private User Delete;
        public UpdateUsers()
        {
            InitializeComponent();
            //Declares a connection to the AlumniWebisteConnectionString
            connectionString = Properties.Settings.Default.AlumniWebsiteConnectionString;
            //Declares new connection using connectionString as its parameter
            connection = new SqlConnection(connectionString);
            Info = new User();
            Update = new User();
            Delete = new User();
        }
        private void UpdateUsers_Load(object sender, EventArgs e)
        {
            this.userTableAdapter.Fill(this.alumniWebsiteDataSet.User);
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            //Sqlstatement to Insert new user into the User database
            string Insert = "INSERT INTO[User] (FirstName, LastName, Email, Password, UserName) "+
                            "VALUES(@pfirstName, @plastName, @pemail, @ppassword, @puserName)";
            //parameterizes new SqlCommand command with Insert and connection
            command = new SqlCommand(Insert, connection);
            //tells the program what data to try and Infointo database
            this.setInfo();
            try
            {
                //Opens database
                connection.Open();
                //Set parameters with values from getInfo
                this.getInfo();
                //Excutes the update Insert SQL statement
                command.ExecuteNonQuery();
            }
            //If theirs an error while executing try
            catch (Exception ex)
            {
                //Display an error messagebox with the error
                MessageBox.Show("DB error: " + ex.Message);
            }
            this.userTableAdapter.Fill(this.alumniWebsiteDataSet.User);
            //close connection
            connection.Close();
        }
        //This method will get information from Textboxs to be added to the database
        private void setInfo()
        {
            //Converts int userID to UserID
            //Info.UserID = int.Parse(userIDTextBox.Text);
            //Declares UserName with userNameTextBox
            Info.UserName = userNameTextBox.Text;
            //Declares FirstName with firstNameTextBox
            Info.FirstName = firstNameTextBox.Text;
            //Declares LastName with lastNameTextBox
            Info.LastName = lastNameTextBox.Text;
            //Declares Email with emailTextBox
            Info.Email = emailTextBox.Text;
            Info.Password = passwordTextBox.Text;
        }
        // gets parameters 
        private void getInfo()
        {
            command.Parameters.AddWithValue("@puserName", Info.UserName);
            command.Parameters.AddWithValue("@pfirstName", Info.FirstName);
            command.Parameters.AddWithValue("@plastName", Info.LastName);
            command.Parameters.AddWithValue("@pemail", Info.Email);
            command.Parameters.AddWithValue("@ppassword", Info.Password);
            command.Parameters.AddWithValue("@puserID", Info.UserID);
        }

        private void btnUpdateUser_Click(object sender, EventArgs e)
        {
            string Update = "UPDATE [User] SET FirstName = @pfirstName, LastName = @plastName, Email = @pemail, Password = @ppassword " +
                            "WHERE(UserID = @puserID)";

            command = new SqlCommand(Update, connection);
            //tells the program what data to try and Infointo database
            this.setUpdate();
            try
            {
                //Opens database
                connection.Open();
                //Set parameters with values from getInfo
                this.getUpdate();
                //Excutes the update Insert SQL statement
                command.ExecuteNonQuery();
            }
            //If theirs an error while executing try
            catch (Exception ex)
            {
                //Display an error messagebox with the error
                MessageBox.Show("DB error: " + ex.Message);
            }
            //Closes connection
            connection.Close();
            //shows changes in database
            this.userTableAdapter.Fill(this.alumniWebsiteDataSet.User);

        } //get parameter for delete
        private void getUpdate()
        {
            command.Parameters.AddWithValue("@puserName", Update.UserName);
            command.Parameters.AddWithValue("@pfirstName", Update.FirstName);
            command.Parameters.AddWithValue("@plastName", Update.LastName);
            command.Parameters.AddWithValue("@pemail", Update.Email);
            command.Parameters.AddWithValue("@ppassword", Update.Password);
            command.Parameters.AddWithValue("@puserID", Update.UserID);
        }
        //sets values for updating data base
        private void setUpdate()
        {
            //Converts int userID to UserID
            Update.UserID = int.Parse(userIDTextBox.Text);
            //Declares UserName with userNameTextBox
            Update.UserName = userNameTextBox.Text;
            //Declares FirstName with firstNameTextBox
            Update.FirstName = firstNameTextBox.Text;
            //Declares LastName with lastNameTextBox
            Update.LastName = lastNameTextBox.Text;
            //Declares Email with emailTextBox
            Update.Email = emailTextBox.Text;
            Update.Password = passwordTextBox.Text;
        }

        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            string Delete = "DELETE FROM [User] WHERE(UserID = @puserID)";
            command = new SqlCommand(Delete, connection);
            //tells the program what data to try and Infointo database
            this.setDelete();
            try
            {
                //Opens database
                connection.Open();
                //Set parameters with values from getInfo
                this.getDelete();
                //Excutes the update Insert SQL statement
                command.ExecuteNonQuery();
            }
            //If theirs an error while executing try
            catch (Exception ex)
            {
                //Display an error messagebox with the error
                MessageBox.Show("DB error: " + ex.Message);
            }
            connection.Close();
            this.userTableAdapter.Fill(this.alumniWebsiteDataSet.User);
        }
        //get parameter for delete
        private void getDelete()
        {
            command.Parameters.AddWithValue("@puserID", Delete.UserID);

        }
        private void setDelete()
        {
            //Converts int userID to UserID
            Delete.UserID = int.Parse(userIDTextBox.Text);
            //Declares UserName with userNameTextBox
            Delete.UserName = userNameTextBox.Text;
            //Declares FirstName with firstNameTextBox
            Delete.FirstName = firstNameTextBox.Text;
            //Declares LastName with lastNameTextBox
            Delete.LastName = lastNameTextBox.Text;
            //Declares Email with emailTextBox
            Delete.Email = emailTextBox.Text;
            Delete.Password = passwordTextBox.Text;
        }

        //Returns user to AdminPage form
        private void btnGoBack_Click(object sender, EventArgs e)
        {
            //Hides form returning the user to the main application
            this.DialogResult = DialogResult.OK;
        }

        private void btnProgram_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
