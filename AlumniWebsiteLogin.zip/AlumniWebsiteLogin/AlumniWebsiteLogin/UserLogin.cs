﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlumniWebsiteLogin
{
    public partial class UserLogin : Form
    {
        //String for the connection
        private string connectionString;
        //Connect to the database
        private SqlConnection connection;
        
        public UserLogin()
        {
            //Instantiates connectionString to AlumniWebsiteConnectionString
            connectionString = Properties.Settings.Default.AlumniWebsiteConnectionString;
            //Instantiates connection using connectionString as a parameter
            connection = new SqlConnection(connectionString);
            InitializeComponent();
        }

       
        private void UserLogin_Load(object sender, EventArgs e)
        {
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            //SqlDataAdapter to use a sql statement that will check the User table to see if username and password are in the table,
            //USER is in [] because USER is a reserved word
            SqlDataAdapter sda = new SqlDataAdapter("SELECT COUNT(*) FROM [USER] WHERE UserName='" + userNameTextBox.Text + "' AND Password='" + passwordTextBox.Text + "'", connection);
            /* in above line the program is selecting the whole data from table and the matching it with the user name and password provided by user. */
            DataTable dt = new DataTable(); //this is creating a virtual table 
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {
                MessageBox.Show("IT WORKS");
                /* I have made a new page called home page. If the user is successfully authenticated then the form will be moved to the next form */
                this.Hide();
                //This opens the main login to validate that it worked
                MainLoginPage frmMainLoginPAge = new MainLoginPage();
                frmMainLoginPAge.ShowDialog();

            }
            else
                MessageBox.Show("Invalid username or password");
        }
        //Displays CreateUserAccounts 
        private void btnNewuser_Click(object sender, EventArgs e)
        {
            //Instantiates frmCreateUserAccount of class CreateUserAccount
            CreateUserAccount frmCreateUserAccount = new CreateUserAccount();
            //Displays CreateUserAccount form
            frmCreateUserAccount.ShowDialog();
        }
    }
    
}
