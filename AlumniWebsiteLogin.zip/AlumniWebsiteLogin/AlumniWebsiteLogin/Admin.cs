﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlumniWebsiteLogin
{
    class Admin
    {
        //Declares private string userName
        private string userName;
        //Declares private string password
        private string password;
        private string firstName;
        private string lastName;
        private int adminID;

        //encapsulates fields of Admin table that will be used,
        //for admin login information
        public string UserName { get => userName; set => userName = value; }
        public string Password { get => password; set => password = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public int AdminID { get => adminID; set => adminID = value; }
    }
}

