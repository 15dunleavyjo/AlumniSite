﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlumniWebsiteLogin
{
    class User
    {
        //Instantiates variable userName
        private string userName;
        //Instantiates variable password
        private string password;
        //Instantiates variable firsName
        private string firstName;
        //Instantiates variable lastName
        private string lastName;
        //Instantiates variable email
        private string email;
        //Instantiates variable userID
        private int userID;
        //encapsulates fields of User table that will be used,
        //for user login information
        public string UserName { get => userName; set => userName = value; }
        public string Password { get => password; set => password = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string Email { get => email; set => email = value; }
        public int UserID { get => userID; set => userID = value; }
    }
}
