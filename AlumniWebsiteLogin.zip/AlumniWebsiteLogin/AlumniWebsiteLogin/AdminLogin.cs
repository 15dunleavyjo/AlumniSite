﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlumniWebsiteLogin
{
    public partial class AdminLogin : Form
    {
        //Instantiates connectionString
        private string connectionString;
        //Instantiates SqlConnection connection
        private SqlConnection connection;
        public AdminLogin()
        {
            InitializeComponent(); 
            //Declares a connection to the AlumniWebisteConnectionString
            connectionString = Properties.Settings.Default.AlumniWebsiteConnectionString;
            //Declares new connection using connectionString as its parameter
            connection = new SqlConnection(connectionString);
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            //SqlDataAdapter to use a sql statement that will check the User table to see if username and password are in the table,
            //USER is in [] because USER is a reserved word
            SqlDataAdapter sda = new SqlDataAdapter("SELECT COUNT(*) FROM ADMIN WHERE UserName='" + userNameTextBox.Text + "' AND Password='" + passwordTextBox.Text + "'", connection);
            /* in above line the program is selecting the whole data from table and the matching it with the user name and password provided by user. */
            DataTable dt = new DataTable(); //this is creating a virtual table 
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {
              
                /* I have made a new page called home page. If the user is successfully authenticated then the form will be moved to the next form */
                this.Hide();
                AdminPage frmAdminPage = new AdminPage();
                frmAdminPage.ShowDialog();
                

            }
            else
                MessageBox.Show("Invalid username or password");
        }
        //Returns user to MainLoginPage form
        private void btnGoBack_Click(object sender, EventArgs e)
        {
            //Hides form returning the user to the main application
            this.DialogResult = DialogResult.OK;
        }
        private void AdminLogin_Load(object sender, EventArgs e)
        {
          
        }

        private void userNameLabel_Click(object sender, EventArgs e)
        {

        }

        private void passwordLabel_Click(object sender, EventArgs e)
        {

        }

        private void passwordTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void userNameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
