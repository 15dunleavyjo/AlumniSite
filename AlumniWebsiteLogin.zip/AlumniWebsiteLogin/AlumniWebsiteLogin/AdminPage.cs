﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlumniWebsiteLogin
{
    public partial class AdminPage : Form
    {
        public AdminPage()
        {
            InitializeComponent();
        }
        //Returns user to MainLoginPage
        private void btnGoBack_Click(object sender, EventArgs e)
        {
            //Hides form returning the user to the main application
            this.DialogResult = DialogResult.OK;
            //Instantiates new frmMainLoginPage of form MainLoginPage
            MainLoginPage frmMainLoginPage = new MainLoginPage();
            //Opens MainLoginPage
            frmMainLoginPage.ShowDialog();
        }

        private void btnUpdateUsers_Click(object sender, EventArgs e)
        {
            //Instantiates new frmUpdateUsers of form UpdateUsers
            UpdateUsers frmUpdateUsers = new UpdateUsers();
            //Opens UpdateUsers form
            frmUpdateUsers.ShowDialog();
        }

        private void btnUpdateAdmin_Click(object sender, EventArgs e)
        {
            //Instantiates new frmUpdateAdmins of form UpdateAdmins
            UpdateAdmins frmUpdateAdmins = new UpdateAdmins();
            //Opens UpdateAdmins form
            frmUpdateAdmins.ShowDialog();
        }
    }
}
