﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlumniWebsiteLogin
{
   
    public partial class CreateUserAccount : Form
    {
        //Instantiates connectionString
        private string connectionString;
        //Instantiates SqlConnection connection
        private SqlConnection connection;
        //Instantiates SqlCommand command
        private SqlCommand command;
        //Instantiates new Insert of class User
        private User Insert;
        public CreateUserAccount()
        {
            InitializeComponent();
            //Declares a connection to the AlumniWebisteConnectionString
            connectionString = Properties.Settings.Default.AlumniWebsiteConnectionString;
            //Declares new connection using connectionString as its parameter
            connection = new SqlConnection(connectionString);
            //Declares new Insert of class User
            Insert = new User();
        }

       
        private void CreateUserAccount_Load(object sender, EventArgs e)
        {   

        }
      
        private void btnAddAccount_Click(object sender, EventArgs e)
        {
            //Sqlstatement to insert new user into the User database
            string Insert = "INSERT INTO User (UserID, FirstName, LastName, Email, Password, UserName) " +
                            "VALUE(@puserID, @pfirstName, @plastName, @pemail, @ppassword, @puserName)";
            //parameterizes new SqlCommand command with Insert and connection
            command = new SqlCommand(Insert, connection);
            //tells the program what data to try and  insert into database
            this.setInsert();
            try
            {
                //Opens database
                connection.Open();
                //Set parameters with values from getInsert
                this.getInsert();
                //Excutes the update Insert SQL statement
                command.ExecuteNonQuery();
            }
            //If theirs an error while executing try
            catch (Exception ex)
            {
                //Display an error messagebox with the error
                MessageBox.Show("DB error: " + ex.Message);
            }
        }
        //This method will get information from Textboxs to be added to the database
        private void setInsert()
        {
           //Converts int userID to UserID
            Insert.UserID = int.Parse(userIDTextBox.Text);
            //Declares UserName with userNameTextBox
            Insert.UserName = userNameTextBox.Text;
            //Declares FirstName with firstNameTextBox
            Insert.FirstName = firstNameTextBox.Text;
            //Declares LastName with lastNameTextBox
            Insert.LastName = lastNameTextBox.Text;
            //Declares Email with emailTextBox
            Insert.Email = emailTextBox.Text;
        }
        private void getInsert()
        {
            //
            command.Parameters.AddWithValue("@puserName", Insert.UserName);
            //
            command.Parameters.AddWithValue("@pfirstName", Insert.FirstName);
            //
            command.Parameters.AddWithValue("@plastName", Insert.LastName);
            //
            command.Parameters.AddWithValue("@pemail", Insert.Email);
            //
            command.Parameters.AddWithValue("@ppassword", Insert.Password);
            //
            command.Parameters.AddWithValue("@puserName", Insert.UserName);
        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {
            //Hides form returning the user to the main application
            this.DialogResult = DialogResult.OK;
        }
    }
}
